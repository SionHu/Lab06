// config/database.js
module.exports = {
	// my db registration 
    //'url' : 'mongodb://localhost/db_name' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'url' :  'mongodb://waynewhbaaa:whb199887@cluster0-shard-00-00-svfyy.mongodb.net:27017,cluster0-shard-00-01-svfyy.mongodb.net:27017,cluster0-shard-00-02-svfyy.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin'
    //'url' : 'mongodb+srv://waynewhbaaa:whb199887@cluster0-svfyy.mongodb.net/test'

};